#Q: Write a python script that will calculate BMI (Body Mass Index). Ask a user to enter height and store the answer in a variable.Ask a user to enter the weight and store the answer in a variable.Based on the height and weight calculate the BMI in the following way:
#weight / height * height
#Print out the BMI to the user

# height of x = 5.3
# weight of x = 60
BMI= 60/5.3 *2 
print(BMI)
print("x has a BMI", 22.64)
print(type(BMI))